def fahrenheit_to_celsius(t):
    t_celcius = t
    return t_celcius

svar = input('Ange en temperatur i Fahrenheit: ')
t = fahrenheit_to_celsius(float(svar))
print("Celsius: ", t)
